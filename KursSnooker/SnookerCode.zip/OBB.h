#pragma once

//class CollisionBoundingVolume;
//struct CollisionData;

