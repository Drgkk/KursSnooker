#pragma once

class GameEvent
{
public:
	virtual void Register() = 0;
};

