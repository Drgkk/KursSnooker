#pragma once

namespace Constants {
	inline constexpr float sleepEpsilon = 0.1f;

}